import sqlite3

connection = sqlite3.connect("chatbot.db")
cursor = connection.cursor()

cursor.execute("SELECT * FROM chats")
rows = cursor.fetchall()

for row in rows:
    print(row)

connection.close()