#Adriana Emmanuelli
#midterm project: AI chatbot
#Artifficial Intelligence 


from flask import Flask ,render_template, request, jsonify 
from openai import OpenAI
import os 
import sqlite3
from dotenv import load_dotenv

#flask=creates web app, openai= allows code to send messages to AI model
#request=lets program receive data sent by user 
#jsonify= sends data back in json format 

#dotenv variables 
load_dotenv()

#inniciating flask app 
app=Flask (__name__)

#Enviorment Variables 
#incialize open AI(I know its preferred for the API key to be hidden, but I couldn't figure that out)
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
#inicializing database, im using sqlite3
def initialize_database():
    connection=sqlite3.connect("chatbot.db")
    cursor=connection.cursor()
#creating the table for my database
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_message TEXT,
        bot_response TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)

    connection.commit()
    connection.close()
#route for chatbot 
#when someone sends data to the chat URL, the chatbot code runs  

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"]) #methods=["POST"] means youre expecting a "post" request
#when someone sends data to the /chat URL run the chatbot code 
def chat():#python function named chat () is used for these kinds of things 
    user_message = request.json.get("message") #getting the users message 
    #request=dagta coming into server,json.get("message")is the data in jSON format,stores variable user_message 
    #try is for error handling 
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "Helpful AI."},
                {"role": "user", "content": user_message}
            ] 
        )#the user types a message 
        #that message gets sent to /chat #the backend processes it #the backend sends back a reply
        reply = response.choices[0].message.content
         #Saving messages to the database 

        def save_chat(user_message,bot_response):
            connection=sqlite3.connect("chatbot.db")
            cursor=connection.cursor()

            cursor.execute("""
            INSERT INTO chats (user_message, bot_response)
            VALUES (?, ?)
            """, (user_message, bot_response))
            connection.commit()
            connection.close()

        return jsonify({"reply": reply})

    except Exception as e:
        return jsonify({"error": str(e)})
    
    

# Run the app
if __name__ == "__main__":
    initialize_database()
    app.run(debug=True)